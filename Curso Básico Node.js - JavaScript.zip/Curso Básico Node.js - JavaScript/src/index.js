//importar o express
const { response } = require('express')
const express = require('express')

//importar a biblioteca uuid versao4 - usado para identificação nas API - id's gerados automaticamente e aleatorios
const { v4: uuidv4 } = require('uuid')

//criando aplicação com o express
const app = express()

app.use(express.json()) //configurando o express para receber JSON

const projetos = []

//Middleware para mostrar no console o nome de cada rota acessada no app
function logRoutes(request, response, next){
    const {method, url} = request //methodo = http - get, put, post..., url é o nome da rota
    const route = `[${method.toUpperCase()}] ${url}`
    console.log(route)
    return next()
}

//chamando o Middleware
app.use(logRoutes)

//criando a primeira rota, que manipula o metodo get na raiz do servidor ('/projetos'), buscando o JSON
//request - traz todas informaçoes que esta sendo enviada/requisitada pelo cliente
//response - formata tudo que ira ser devolvido para o cliente, como textos por exemplo
//request.query = parametros de consulta
app.get('/projetos', function(request, response){
    return response.json(projetos)
})

//criando a segunda rota, que manipula o metodo post na raiz do servidor ('/projetos'), adicionando um recurso
app.post('/projetos', function(request, response){
    const {name, owner} = request.body //body recebera um JSON com as informações que esta sendo criada para o novo projeto
    const projeto = {
        id: uuidv4(),
        name,
        owner
    }

    projetos.push(projeto)

    return response.status(201).json(projeto)
})

//criando a terceira rota, que manipula o metodo put na raiz do servidor ('/projetos'), atualizando um recurso
app.put('/projetos/:id', function(request, response){
    const {id} = request.params //parametros de rota = request.params
    const {name, owner} = request.body
    
    const projetoIndex = projetos.findIndex(p => p.id === id) //percorre ate o id armazenado em p seja igual ao id informado pelo cliente
    if(projetoIndex < 0){ //se tiver retorno de -1, ou seja, nao encontrou nenhum id informado, retornara erro 404
        return response.status(404).json({error: 'Projeto nao encontrado'})
    }

    if(!name || !owner){ //se nao tiver sido informado valor em nenhum dos dois params, retorna erro 400
        return response.status(400).json({error: 'Name e Owner sao requeridos'})
    }

    const projeto = {
        id, 
        name,
        owner
    }

    //atribuindo para o array (projetos) na posicao (projetoIndex - func acima), o que esta salvo na const projeto (id, name, owner)
    projetos[projetoIndex] = projeto

    return response.json(projeto)
})

//criando a quarta rota, que manipula o metodo delete na raiz do servidor ('/projetos'), excluindo um recurso
app.delete('/projetos/:id', function(request, response){
    const {id} = request.params //parametros de rota = request.params

    const projetoIndex = projetos.findIndex(p => p.id === id) //percorre ate o id armazenado em p seja igual ao id informado pelo cliente
    if(projetoIndex < 0){ //se tiver retorno de -1, ou seja, nao encontrou nenhum id informado, retornara erro 404
        return response.status(404).json({error: 'Projeto nao encontrado'})
    }

    projetos.splice(projetoIndex, 1)

    return response.status(204).send()
})

//servidor http express ta sendo responsavel por ouvir(listen) as requisiçoes que chegam na porta 4000 do meu pc
app.listen(4000, () => {
    console.log('Servidor iniciado na porta 4000!')
})
